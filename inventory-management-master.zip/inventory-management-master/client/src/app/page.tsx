import Dashboard from "@/app/dashboard/page";

export default function Home() {
  return <Dashboard />;
}
